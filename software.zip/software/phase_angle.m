function phase_a=phase_angle(a1,a2,b)
% This function computes the phase angle
% a1,a2:2 zenith angle , b: relative azimuth angle

temp=cos(a1).*cos(a2)+sin(a1).*sin(a2).*cos(b)
phase_a = acos(temp);
end