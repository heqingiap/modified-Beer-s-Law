function cc=point_gen_clump(d,r0,n,r_min,depth)
% This function generates the three dimensional coordinates of points (crown
% centers) with horizontally aggregative distribution and vertically random distribution
 
% d:     length of side of the square shaped study area
% r0:    horizontal radius of the spheroidal shaped crowns
% n:     maximum number of crown to be generated
% r_min: minimum horizontal distance 
% depth: maximun vertical distance between two crowns.
% cc:    three dimensional coordinates of points (crown centers)

d_clump = d/2;
n_clump = floor(n*4/10);

cc1 = point_gen_2d(d_clump,r0,n_clump,r_min);
cc1(:,1)=cc1(:,1)+d/4;
cc1(:,2)=cc1(:,2)+d/4;

d_clump = d/2;
n_clump = floor(n*4/10);
cc3 = point_gen_2d(d_clump,r0,n_clump,r_min);

cc3(:,1)=cc3(:,1)-d/4;
cc3(:,2)=cc3(:,2)-d/4;

n_rest = n-size(cc1,1)-size(cc3,1);
%cc2 = d .* rand(n_rest,2)-d/2;
cc2 = (d-2.*r0) .* rand(n_rest,2)-(d/2-r0);
cc=vertcat(cc1,cc2,cc3);

nc = size(cc,1);
% 2D-->3D
cc(:,3)=rand(nc,1).*depth -0.5*depth;
end
