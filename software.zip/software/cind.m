function ci=cind(a,nc,oa)
% this function compute the clumping index (ci)
 
    x = 1-exp(-a.*nc); gr=1-x;na=a.*nc;
    fa=f1(oa); fb=f2(oa);
    ci=(1-fa.*x)./(1-fb.*x);p=exp(-ci.*na);
    ind2=abs(1-fb.*x) <=0.1;
    ind1 = p>=0.99 | p<=0.001;
    fa=oa.*0.5;fb=0.5;
    c1=(1-fa.*x)./(1-fb.*x);
    c2 =(ci.*gr)+(c1.*x);
    ci(ind2)=c2(ind2);
    ci(ind1)=c1(ind1);
end


function fit_a=f1(x) % x:oa;
ind=(x<=2);
p1=0.1773;p2 =-0.1617;p3 =5.861;q1 =4.913;
fit_a=(p1.*x.^2 + p2.*x + p3) ./ (x + q1);
p1 = 0.4476;p2 =-0.6858;p3 =3.745;p4 = 0.8001;q1 =2.763;q2 =0.6883;
t= (p1.*x.^3 + p2.*x.^2 + p3.*x + p4) ./ (x.^2 + q1.*x + q2);
fit_a(ind)=t(ind);
end

function fit_b=f2(x) % x:oa;
ind=(x<=2);
p1=-1251;p2 =3430;q1 =66.06;q2 =2243;
fit_b= (p1.*x + p2) ./ (x.^2 + q1.*x+q2);
p1=-6.028;p2=16.46;q1=-1.161;q2=10.87;
t= (p1.*x + p2) ./ (x.^2 + q1.*x+q2);
fit_b(ind)=t(ind);
end

