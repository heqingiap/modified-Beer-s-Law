function [s,n_h_r0,n_r_r0,n_alpha,dc]=d_o_data()
% This function generates the look-up-table of overlapping proportion (o_data)
% o_data is the function of crown shape, location, and direction, but contains no distribution information

global rv_r0 dr_r0 dh_r0
global o_data theta n_theta
 
n_alpha = 180;
r_r0_max = 50; 
h_r0_max = 5; 
delta_alpha = pi*2/n_alpha;
alpha = delta_alpha/2:delta_alpha:pi*2;

r_r0 = dr_r0/2:dr_r0:r_r0_max; n_r_r0 = numel(r_r0); m1 = 1:n_r_r0;
s = 2 .* m1 ./ (n_r_r0 .^2);   % area proportion of each ring

h_r0 = -h_r0_max:dh_r0:h_r0_max; n_h_r0 = length(h_r0);

dc = sqrt(cos(theta) .^2 + (rv_r0 .* sin(theta)).^2);
% dc: major axis of the crown projection in the plane perpendicular to the incident/viewing direction 

o_data=zeros(n_r_r0,n_alpha,n_theta,n_h_r0); 
% o_data: the data set of overlapping proportion (ring,azimuth,zenith,layer)
for q=1:n_h_r0 
    for k=1:n_theta
        [dx,dy,d] = dx_dy_d(r_r0,h_r0(q),theta(k),alpha); 
        o = o_ellipsoid(dx,dy,dc(k));
        o_data(:,:,k,q)=o;
    end
end



