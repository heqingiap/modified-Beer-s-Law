function [bincounts,p_h,binranges]= dist_vert(cc,d_h_r0)
% This function computes the vertical distribution of points

z = cc(:,3);
binranges = min(z):d_h_r0:(max(z)+d_h_r0);       
[bincounts,ind] = histc(z,binranges);
p_h = bincounts ./ numel(z);
end
