function p_h = gh_gen(hp)
% This function computes the distribution of vertical distance between each pair of points

n = length(hp);
hp=reshape(hp,1,n);

for m=0:1:(n-1); 
    k=n-m; 
    t1=1+m;t2=k+m;
    a=hp(1:k);b=hp(t1:t2);c=a*(b');
    p_h(m+1)=c; 
end
end


    
   