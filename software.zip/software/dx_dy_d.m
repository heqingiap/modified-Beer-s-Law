function [dx,dy,d] = dx_dy_d(r_r0,h_r0,theta,alpha)
% This function computes the distance between two points on the plane perpendicular to the incident/viewing direction

% d:  distance between two points in incident/viewing direction 
% dx, dy:  x-component and y-component of d 
% r_r0: r/r0, r is the horizontal distance of the two points
% h_r0: h/r0��h is the vertical distance of the two points 
% theta: zenith angle
% alpha: azimuth angle

dx = r_r0' * cos(alpha) ;    

t1 = r_r0' * (sin(alpha) .* cos(theta)); 
t2 = h_r0 .* sin(theta);  
dy = t1 + ones(size(t1)) .* t2;

d = sqrt(dx .^ 2 + dy .^ 2);
end


