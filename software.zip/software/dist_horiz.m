function [binranges,pr]= dist_horiz(cc,cc9,dr_r0)
% This function computes the second-order statistic on the horizontal plane

% cc:    three dimensional coordinates of points (crown centers) in study region
% cc9:   three dimensional coordinates of points (crown centers) in in 3*3 region
% dr_r0: dr/r0
% binranges:  bin ranges, for histc function
% pr:    distribution of the horizontal distance of two crown centers,
%        = g(r)*2*pi*r*dr/A in equation (9)

x=cc(:,1);
y=cc(:,2);
z=cc(:,3);

x_9=cc9(:,1);
y_9=cc9(:,2);
z_9=cc9(:,3);

num = length(x);  

for k = 1:num;   
    x1 = x_9 - x(k);
    y1 = y_9 - y(k);
    z1 = z_9 - z(k);
    xyz1 = horzcat(x1,y1,z1);
    if k == 1  
        position=xyz1;
    else
        position = vertcat(position,xyz1); 
    end 
end
    
x2=position(:,1);
y2=position(:,2);
z2=position(:,3);

[angle,r] = cart2pol(x2,y2);     
binranges = 0:dr_r0:(max(r)+dr_r0);  

[bincounts,ind] = histc(r,binranges);
bincounts(1)=bincounts(1)-num; 
pr = bincounts' ./ (num-1)./num;
end




    
