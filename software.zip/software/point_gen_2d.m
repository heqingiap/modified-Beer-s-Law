function cc=point_gen_2d(d,r0,n,r_min)
% This function generates the two dimensional coordinates (XY) of points following Poission distribution, with minimum horizontal distance r_min
% r_min = 0: horizontally random distribution; r_min >0: horizontally regular distribution

n_cand = 5000; 
cc_cand = (d-2.*r0) .* rand(n_cand,2)-(d/2-r0);
%cc_cand = d .* rand(n_cand,2)-d/2;
cc(1,:)=cc_cand(1,:);m=1; 
for k=2:n_cand
    cc_exist=cc_cand(1:(k-1),:);
    l=cc_exist-repmat(cc_cand(k,:),(k-1),1);
    [angle,r] = cart2pol(l(:,1),l(:,2));
    if min(r)>=r_min
        m=m+1;
        cc(m,:)=cc_cand(k,:);
    end
    if m==n
        break
    end
end
end    
    
    

  

