function [o_1,dc] = o_ave
% This function computes the mean overlapping proportion (o_1) of two crowns
% o_1 contains the distribution information

% o_1: mean overlapping proportion of any two crowns in scene (O in equation 9)
% dc: major axis of the crown projection in the plane perpendicular to the incident/viewing direction 


global rv_r0 dr_r0 dh_r0
global p_r binranges_hor p_h binrange_vert
global o_data theta n_theta


[s,n_h_r0,n_r_r0,n_alpha,dc] = d_o_data();
n_ring = min(numel(p_r),n_r_r0);
o_data_cut = o_data(1:n_ring,:,:,:);
p_r_cut=p_r(1:n_ring);
h = max(binrange_vert); 
n_layer = numel(p_h);
if n_layer<1;
    n_layer=1;
end; 
n_h = 2.*n_layer-1; 
mid = (1+n_h_r0)/2; 

o_ph = zeros(n_ring,n_alpha,n_h);
o_1 = zeros(1,n_theta);

for k=1:n_theta 
    for q=1:n_layer 
        q1=mid+(q-1);q2=mid-(q-1);qq1=n_layer+(q-1);qq2=n_layer-(q-1);
        o = o_data_cut(:,:,k,q1);
        o_ph (:,:,qq1) = o .* p_h(q);
        o = o_data_cut(:,:,k,q2);
        o_ph (:,:,qq2) = o .* p_h(q);
    end
    temp01 = sum(o_ph,3); 
    temp02 = mean (temp01,2);
    temp03 = temp02';
    temp04 = temp03 .* p_r_cut; 
    o_1(k) = sum(temp04); 
end
    
  