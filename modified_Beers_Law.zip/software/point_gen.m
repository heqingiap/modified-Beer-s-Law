function cc=point_gen(d,r0,n,r_min,depth)
% This function generates the three-dimensional coordinates of points following Poisson distribution, with minimum horizontal distance r_min
% r_min = 0: horizontally random distribution; r_min >0: horizontally regular distribution
% depth = 0: located at the same height; depth > 0: vertically randomly distributed in the range [-depth/2, depth/2]

% generate the 2D coordinates (xy) 
cc=point_gen_2d(d,r0,n,r_min);
nc = size(cc,1);
% 2D-->3D
cc(:,3)=rand(nc,1).*depth -0.5*depth;
end    
    
    

  

