function o_sphere = o_sphere(d)
% This function computes the overlapping proportion of two circles

index_1 = d < 2;
o_sphere = zeros( size(d) );
d_1 = d(index_1); 
t1 = d_1 ./ 2;   % d/2
t2 = acos(t1);   % arccos(d/2)
t3 = 1 - t1.^2;  % 1-(d/2)^2
t4 = sqrt( t3);  % sqrt(1-(d/2)^2)
o_1= 2 .* (t2 - t1 .* t4) ./ pi;
o_sphere(index_1) = o_1;

end

