function cc_new = cc_large(cc,d)
% This function computes the coordinates of points, after duplication of study area (to eliminate edge effect)

n = 3;                
a = -(n-1)/2:(n-1)/2;  
aa = d.*a;

x=cc(:,1);
y=cc(:,2);
z=cc(:,3);
cc_new = [];

for k = 1:n
    y1 = y + aa(k);
    for m = 1:n
        x1 = x + aa(m);
        xyz1 = horzcat(x1,y1,z);
        cc_new = vertcat(cc_new,xyz1);
    end
end

end
    

