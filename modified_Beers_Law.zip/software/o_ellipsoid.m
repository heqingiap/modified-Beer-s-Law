function o_ellipsoid = o_ellipsoid(dx,dy,dc)
% This function computes the overlapping proportion of two ellipses

dy_transformed = dy ./ dc;
d_transformed = sqrt(dx .^2 + dy_transformed .^2);
o_ellipsoid = o_sphere(d_transformed);

end
